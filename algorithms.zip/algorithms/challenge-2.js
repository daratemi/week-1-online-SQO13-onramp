function fizzBuzz(input){

  
}


module.exports = fizzBuzz
