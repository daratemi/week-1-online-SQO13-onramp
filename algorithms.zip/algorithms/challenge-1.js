function countTruthy(arr) {

}
module.exports = countTruthy