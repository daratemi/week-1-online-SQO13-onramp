function sumMix(arr) {
   
 }

  module.exports = sumMix