function calculateGrade(marks) {
 
 }
  module.exports =calculateGrade
